﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Cadastro_Aluno_Modelo
{
    public class mdlAluno
    {
        public int idAluno {get;set;}
        public string Nome { get; set; }
        public string RG { get; set; }
        public string CPF { get; set; }

        
    }
}
